package TMAP;

import static org.junit.Assert.*;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;

import java.net.URL;
import java.util.HashMap;
import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebElement;

public class TmapDemoTest {

public AndroidDriver driver;

	
	
	@Before
	public void setUp() throws Exception {

		DesiredCapabilities capabilities = new DesiredCapabilities();
		capabilities.setCapability("deviceName", "test");
		capabilities.setCapability("platformVersion", "4.4");
		capabilities.setCapability("unicodeKeyboard",true);
		
		driver = new AndroidDriver(new URL("http://127.0.0.1:4723/wd/hub"),capabilities);
		driver.manage().timeouts().implicitlyWait(8, TimeUnit.SECONDS);
	}

	@After
	public void tearDown() throws Exception {
//   driver.quit();
	}

	@Test
	public void test() throws InterruptedException {
		//첫실행 팝업 "다시 보지 않기" 클릭		
		WebElement e1 = driver.findElement(By.id("com.skt.skaf.l001mtm091:id/check_box"));
		e1.click();
		//T-MAP 실행하기 버튼 클릭
		WebElement e2 = driver.findElement(By.className("android.widget.Button").id("com.skt.skaf.l001mtm091:id/ad_box_img"));
		e2.click();
		//검색창 클릭
		WebElement e3 = driver.findElement(By.id("com.skt.skaf.l001mtm091:id/input_search"));
		e3.click();
		//sk플래닛 글 입력
		WebElement e4 = driver.findElement(By.className("android.widget.EditText").id("com.skt.skaf.l001mtm091:id/qm_input_search"));
		e4.sendKeys("sk플래닛");
		//검색버튼 클릭
		WebElement e5 = driver.findElement(By.className("android.widget.ImageView").id("com.skt.skaf.l001mtm091:id/qm_search_icon"));
		e5.click();
		//결과 리스트중 "SK플래닛 제2사옥" 찾기
		String result ="SK플래닛 제2사옥";
		serachh(result);
		//결과 리스트중 "SK플래닛 제2사옥" 클릭
		WebElement e6 = driver.findElement(By.id("com.skt.skaf.l001mtm091:id/search_result_list_template_textview_name").name(result));
		e6.click();
		//클릭 한 값이 찾으려는 값하고 동일한지 검사문
		System.out.println(e6.getText().toString() + "/" + result);
		assertEquals(e6.getText().toString(), result);
		//다른 경로 클릭
		WebElement e7 = driver.findElement(By.className("android.widget.Button").id("com.skt.skaf.l001mtm091:id/routeOptionBtn"));
		e7.click();
		//초보자 우선 경로 클릭
		WebElement e8 = driver.findElement(By.className("android.widget.FrameLayout").id("com.skt.skaf.l001mtm091:id/beginner_route_layout"));
		e8.click();
		//언제갈까 클릭
		WebElement e9 = driver.findElement(By.className("android.widget.Button").id("com.skt.skaf.l001mtm091:id/timePredictBtn"));
		e9.click();
		//닫기 버튼 클릭
		WebElement e13 = driver.findElement(By.className("android.widget.ImageView").id("com.skt.skaf.l001mtm091:id/btnClose"));
		e13.click();
		//안내 시작 클릭
		WebElement e14 = driver.findElement(By.className("android.widget.Button").id("com.skt.skaf.l001mtm091:id/naviStartBtn"));
		e14.click();
		//메뉴		
		WebElement e15 = driver.findElement(By.className("android.widget.ImageButton").id("com.skt.skaf.l001mtm091:id/driving_menu_btn"));
		e15.click();
		//경로취소
		WebElement e16 = driver.findElement(By.className("android.widget.Button").id("com.skt.skaf.l001mtm091:id/driving_menu_item_cancel_route_guide"));
		e16.click();
		//경로취소 버튼 클릭
		WebElement e17 = driver.findElement(By.className("android.widget.Button").id("com.skt.skaf.l001mtm091:id/btn0"));
		e17.click();
		//지도 밑 닫기
		WebElement e18 = driver.findElement(By.className("android.widget.ImageButton").id("com.skt.skaf.l001mtm091:id/ando_stop_ando_mode"));
		e18.click();
		//즐겨찾기 클릭
		WebElement e19 = driver.findElement(By.className("android.widget.ImageView").id("com.skt.skaf.l001mtm091:id/quick_btn_favoite_list"));
		e19.click();
		//즐겨찾기 목록 즁 "유스페이스 2동" 찾기
		String data1 = "유스페이스 2동";
		serachh(data1);
		//즐겨찾기 목록 중 "유스페이스 2동" 클릭
		WebElement e20 = driver.findElement(By.name("유스페이스 2동"));
		e20.click();
		
		
		
	}
	//해당 값을 찾는 스크롤
	public void serachh(String data1) {
		HashMap<String, String> scrollObject = new HashMap<String, String>();
		RemoteWebElement element = (RemoteWebElement) driver
				.findElementByAndroidUIAutomator("new UiSelector().className(\"android.widget.ListView\")");
		JavascriptExecutor js = (JavascriptExecutor) driver;
		String webElementId = ((RemoteWebElement) element).getId();
		scrollObject.put("text", data1);
		scrollObject.put("element", webElementId);
		js.executeScript("mobile: scrollTo", scrollObject);
	}
	
	
	
	

}
