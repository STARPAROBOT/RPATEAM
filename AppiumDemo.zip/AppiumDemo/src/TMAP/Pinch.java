package TMAP;

import static org.junit.Assert.*;

import java.net.URL;
import java.util.concurrent.TimeUnit;

import io.appium.java_client.MultiTouchAction;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;

import com.sun.javafx.scene.paint.GradientUtils.Point;

public class Pinch {
	
	
	public AndroidDriver driver;

	@Before
	public void setUp() throws Exception {

		DesiredCapabilities capabilities = new DesiredCapabilities();
		capabilities.setCapability("deviceName", "test");
		capabilities.setCapability("platformVersion", "4.4");
		capabilities.setCapability("unicodeKeyboard",true);
		driver = new AndroidDriver(new URL("http://127.0.0.1:4723/wd/hub"),capabilities);

		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

	}

	
	@After
	public void tearDown() throws Exception {
   driver.quit();
	}
	
	
	@Test
	public void test() throws InterruptedException {
		
		WebElement e1 = driver.findElement(By.id("com.skt.skaf.l001mtm091:id/check_box"));
		e1.click();
		
		WebElement e2 = driver.findElement(By.className("android.widget.Button").id("com.skt.skaf.l001mtm091:id/ad_box_img"));
		e2.click();
		
		WebElement e3 = driver.findElement(By.className("android.widget.ImageButton").id("com.skt.skaf.l001mtm091:id/tmap_tile"));
		e3.click();

		WebElement e4 = driver.findElement(By.className("android.view.View"));
		e4.click();
		
		
		
		//아래로 
		driver.swipe (475, 1681, 483 , 327, 400);
		Thread.sleep(1000);

		//위로
		driver.swipe (475,460,475,1681,400);
		Thread.sleep(1000);
		
		
		//왼쪽
		driver.swipe (236, 944, 905 , 970, 400);
		Thread.sleep(1000);
		
		
		
		//오른쪽
		driver.swipe (905, 970, 236 , 944, 400);
		Thread.sleep(1000);
		
		//화면 크게
		MultiTouchAction multiTouchAction1 = new MultiTouchAction(driver);
		TouchAction action2 = new TouchAction(driver).press(492, 808).moveTo(127,295).release();
		TouchAction action3 = new TouchAction(driver).press(500, 932).moveTo(977, 1476).release();
		multiTouchAction1.add(action2).add(action3);
		multiTouchAction1.perform();
		
		Thread.sleep(3000);
		
		
		//Pinch (화면 줄이기)
		MultiTouchAction multiTouchAction = new MultiTouchAction(driver);
		WebElement e5 = driver.findElement(By.className("android.view.View"));
		Dimension dimension = e5.getSize();
		System.out.println(dimension);
		org.openqa.selenium.Point upperLeft = e5.getLocation();
		System.out.println(upperLeft);
		org.openqa.selenium.Point center = new org.openqa.selenium.Point(upperLeft.getX() + dimension.getWidth() /2, upperLeft.getY() + dimension.getHeight()/2);
		System.out.println(center);
		TouchAction action0 = new TouchAction(driver).press(e5,center.getX(),center.getY() - 100).moveTo(e5).release();
		TouchAction action1 = new TouchAction(driver).press(e5, center.getX(),center.getY() + 100).moveTo(e5).release();

		
	}

}
